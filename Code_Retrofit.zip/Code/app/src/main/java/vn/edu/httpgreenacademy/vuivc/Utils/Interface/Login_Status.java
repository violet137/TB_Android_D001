package vn.edu.httpgreenacademy.vuivc.Utils.Interface;

public interface Login_Status {
    void LoginStatus(Boolean isThanhCong);
}
