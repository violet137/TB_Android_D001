package vn.edu.httpgreenacademy.vuivc.Utils.Interface;

public interface Register_Statis {
    void RegisterStatus(Boolean isThanhCong);
}
